
package com.tweets;
import java.io.IOException;
import java.util.ArrayList;

import twitter4j.IDs;
//import twitter4j.IDs;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;
import twitter4j.auth.AccessToken;

	public class Follower
	{
		
		static int counter = 0;
		String tname;
		public static String consumerKey1 = "i98lWOVZ6DLARCIIQlx5VFOuC";
	    public static String consumerSecret1 = "AUUpp6zwJf2DvVo0vk6w1BMrpFPGH7YY22YA4kNq5DQ4Hyrtcb";
	    public static String twitterToken1 = "1493129694-lDWmDcfz1CGmTbs79hbGHykxTgfqOYlXBGofMfi";
	    public static String twitterSecret1 = "NbIUCMsZ5WDEwQFHhUq6AvM10qimq2k9NEy46I35fos85";

	    public static String consumerKey2 = "C2H4dwpT2ErAYBEyTKCmgwZ7G";
	    public static String consumerSecret2 = "1991VfQPnFLKyveZ7I3jsVc2Z1aqmMXp0hBAPUkzEGyz0Ar0Bb";
	    public static String twitterToken2 = "782967513550245888-PJygr7JOoZaYgNAUzv4EoLW5J40I85h";
	    public static String twitterSecret2 = "MP6GlXUOgjh7ryO7GgdSkRN4nGLWkbUeqt36qPuQE9Aga";

	    public static String consumerKey3 = "20FAzMZybVstsw63kQa8ZteHJ";
	    public static String consumerSecret3 = "Zcl8eaQA941CcCIMAXuZonF5YO65vxLyOnIX5YA1GIBzHOMq1b";
	    public static String twitterToken3 = "782967513550245888-dhq5g2Kv8VzdbWtlAaBov3o4niz8AEz";
	    public static String twitterSecret3 = "ej3Bowpn6eamyUulzWfHshnnLpm0Y6EMJnGWQyGpfTrnM";

	    public static String consumerKey4 = "BVac9nwEMtCHzHyw20whl4uDs";
	    public static String consumerSecret4 = "P2wasCnZ5LmvZ0UHsM8zIe5NGtBT7Ks6aetz3nT6OOJJuTOXkl";
	    public static String twitterToken4 = "782967513550245888-d9bYbPRyY6HVjA1r8GFkJixlhtDRLV0";
	    public static String twitterSecret4 = "a1OM1M9FHDMd7tczBfWSJMDqaTwYtxl7tG9TA4M13ez1i";

	    public static String consumerKey5 = "MzOKxEs58SZCE2WF2bxpkUc6h";
	    public static String consumerSecret5 = "sPojZMrfA8Z4oUwKsCOFMr2YT3O2SVssruarkXpcG0sj6ywHYR";
	    public static String twitterToken5 = "1952264970-4m0FrljMSc6mVhewNPlBX8odLZnLFg5TPpG6iHh";
	    public static String twitterSecret5 = "FPAYcegFSD0WV0rN3NxvbJ6xnAB3KvvL2m1EESKQOXpb5";

	    public static String consumerKey6 = "femNtVmoTNOJDnp1y7qqAMkOK";
	    public static String consumerSecret6 = "nmuSJHyN1hezcwVfZVz0uxOso5PgtAs5YThwspoNQfxdeCimTu";
	    public static String twitterToken6 = "1952264970-zoLRBDT08fAYsCKjO7oemmkGs05D2dici08m3TA";
	    public static String twitterSecret6 = "v6Z3n5lRvuTPqgpHTsN7iuS4zWMzxGeZAVAKOfvDnhPWj";

	    public static String consumerKey7 = "KJxpW9WiW2FBL2DMBEvpznGmn";
	    public static String consumerSecret7 = "87Jk7AqHJ1SjOiAlttWmrtVYiBMMPh0zz9pSYUM4plv7qiSPrS";
	    public static String twitterToken7 = "1952264970-s0kQXbsPsiN2C1VaVxFWUwcWY6wd14qozmDjzSn";
	    public static String twitterSecret7 = "4AaaB4OalScIr3nV9TFqsvkvEQ0Qf6gZHJXiQJEdP72uP";

	    public static String consumerKey8 = "G3XKzZc2wdk00be88F8F0rcFp";
	    public static String consumerSecret8 = "X7bzValwWWH38J7UnC9CFCl4usLBhampk1D6DgvSLACj3jsBkZ";
	    public static String twitterToken8 = "1493129694-qjSILLROjfzqOZv0kdbRDoXRNY23NYjFafqvrHW";
	    public static String twitterSecret8 = "TdpJ3Wzxa678qWKSwxDpzD0hqOQm3yKtoMoP4S7IdcaRo";

	    public static String consumerKey9 = "uuRfN1Nls8ctJe0cOTPohvllc";
	    public static String consumerSecret9 = "s47mZT2Loic41pYvg6gl8LeykHgHOpGfndzfW0snCB5IjsP1eg";
	    public static String twitterToken9 = "1493129694-3DyYUlXuZoQhwmvGZMDA5EbY6xtGTKCjQMH6Urg";
	    public static String twitterSecret9 = "0dlgzewDBx3hbbco6IVbuTW1b4fdRyoiRtap0b20xfAVV";

	    public ArrayList<String> ar = new ArrayList();
	    public ArrayList<String> arpic = new ArrayList();

	    public void setTname(String tname) {
	        this.tname = tname;
	    }

	    public String getTname() {
			return tname;
		}

		public ArrayList getFollow() throws Exception {
	        this.getDetails8();
	        return this.ar;
	    }
	    
	    public ArrayList getFollowPic() throws IOException, TwitterException {
	    	//this.getDetails();
	    	return this.arpic;
	    }         

			public void getDetails1() throws IOException, TwitterException {
		        String twittername = this.tname;
		        System.out.println(twittername);
		        //String consumerKey = "i98lWOVZ6DLARCIIQlx5VFOuC";
		        //String consumerSecret = "AUUpp6zwJf2DvVo0vk6w1BMrpFPGH7YY22YA4kNq5DQ4Hyrtcb";
		        //String twitterToken = "1493129694-lDWmDcfz1CGmTbs79hbGHykxTgfqOYlXBGofMfi";
		        //String twitterSecret = "NbIUCMsZ5WDEwQFHhUq6AvM10qimq2k9NEy46I35fos85";
		        TwitterFactory factory1 = new TwitterFactory();
		        Twitter twitter1 = factory1.getInstance();
		        twitter1.setOAuthConsumer(consumerKey1, consumerSecret1);
		        AccessToken accessToken1 = new AccessToken(twitterToken1, twitterSecret1);
		        twitter1.setOAuthAccessToken(accessToken1);
		        String twitterScreenName = twitter1.getScreenName();
		        
		        IDs followerIDs = twitter1.getFollowersIDs(twitterScreenName, -1);
		        long[] ids = followerIDs.getIDs();
		        String usr = twittername;
		        try {
		            long[] fofIDs;
		            User user = twitter1.showUser(usr);
		            
		            String userScreenName = user.getScreenName();
		            IDs followerIDsOfFollowers = twitter1.getFollowersIDs(user.getScreenName(), -1);
		            long[] arrl = fofIDs = followerIDsOfFollowers.getIDs();
		            int n = arrl.length;
		            int n2 = 0;
		            while (n2 < n) {
		            	if(counter == 15)
                    		break;
		                long subId = arrl[n2];
		                User user1 = twitter1.showUser(subId);
		                if(user1.getStatusesCount() > 200 && user1.getStatusesCount() < 5000){
		                	this.ar.add(user1.getScreenName());
		                    this.arpic.add(user1.getMiniProfileImageURL());
		                    System.out.println("status : "+user1.getRateLimitStatus().getRemaining());
		                    if(user1.getRateLimitStatus().getRemaining() < 300){
		                    	counter = counter+1;
		                    	System.out.println("getDetails2 called");
		                    	System.out.println("Counter :"+counter);
		                    	getDetails2();
		                    }
		                }
		                ++n2;
		            }
		        }
		        catch (TwitterException e1) {
		            e1.printStackTrace();
		        }
		    }
			public void getDetails2() throws IOException, TwitterException {
		        String twittername = this.tname;
		        System.out.println(twittername);
		        //String consumerKey = "i98lWOVZ6DLARCIIQlx5VFOuC";
		        //String consumerSecret = "AUUpp6zwJf2DvVo0vk6w1BMrpFPGH7YY22YA4kNq5DQ4Hyrtcb";
		        //String twitterToken = "1493129694-lDWmDcfz1CGmTbs79hbGHykxTgfqOYlXBGofMfi";
		        //String twitterSecret = "NbIUCMsZ5WDEwQFHhUq6AvM10qimq2k9NEy46I35fos85";
		        TwitterFactory factory2 = new TwitterFactory();
		        Twitter twitter2 = factory2.getInstance();
		        twitter2.setOAuthConsumer(consumerKey2, consumerSecret2);
		        AccessToken accessToken2 = new AccessToken(twitterToken2, twitterSecret2);
		        twitter2.setOAuthAccessToken(accessToken2);
		        String twitterScreenName = twitter2.getScreenName();
		        
		        IDs followerIDs = twitter2.getFollowersIDs(twitterScreenName, -1);
		        long[] ids = followerIDs.getIDs();
		        String usr = twittername;
		        try {
		            long[] fofIDs;
		            User user = twitter2.showUser(usr);
		            
		            String userScreenName = user.getScreenName();
		            IDs followerIDsOfFollowers = twitter2.getFollowersIDs(user.getScreenName(), -1);
		            long[] arrl = fofIDs = followerIDsOfFollowers.getIDs();
		            int n = arrl.length;
		            int n2 = 0;
		            while (n2 < n) {
		            	if(counter == 15)
                    		break;
		                long subId = arrl[n2];
		                User user1 = twitter2.showUser(subId);
		                if(user1.getStatusesCount() > 200 && user1.getStatusesCount() < 5000){
		                	this.ar.add(user1.getScreenName());
		                    this.arpic.add(user1.getMiniProfileImageURL());
		                    System.out.println("status : "+user1.getRateLimitStatus().getRemaining());
		                    if(user1.getRateLimitStatus().getRemaining() < 300){
		                    	counter = counter+1;
		                    	System.out.println("getDetails3 called");
		                    	System.out.println("Counter :"+counter);
		                    	getDetails3();
		                    }
		                }
		                ++n2;
		            }
		        }
		        catch (TwitterException e1) {
		            e1.printStackTrace();
		        }
		    }
			public void getDetails3() throws IOException, TwitterException {
		        String twittername = this.tname;
		        System.out.println(twittername);
		        //String consumerKey = "i98lWOVZ6DLARCIIQlx5VFOuC";
		        //String consumerSecret = "AUUpp6zwJf2DvVo0vk6w1BMrpFPGH7YY22YA4kNq5DQ4Hyrtcb";
		        //String twitterToken = "1493129694-lDWmDcfz1CGmTbs79hbGHykxTgfqOYlXBGofMfi";
		        //String twitterSecret = "NbIUCMsZ5WDEwQFHhUq6AvM10qimq2k9NEy46I35fos85";
		        TwitterFactory factory3 = new TwitterFactory();
		        Twitter twitter3 = factory3.getInstance();
		        twitter3.setOAuthConsumer(consumerKey3, consumerSecret3);
		        AccessToken accessToken3 = new AccessToken(twitterToken3, twitterSecret3);
		        twitter3.setOAuthAccessToken(accessToken3);
		        String twitterScreenName = twitter3.getScreenName();
		        
		        IDs followerIDs = twitter3.getFollowersIDs(twitterScreenName, -1);
		        long[] ids = followerIDs.getIDs();
		        String usr = twittername;
		        try {
		            long[] fofIDs;
		            User user = twitter3.showUser(usr);
		            
		            String userScreenName = user.getScreenName();
		            IDs followerIDsOfFollowers = twitter3.getFollowersIDs(user.getScreenName(), -1);
		            long[] arrl = fofIDs = followerIDsOfFollowers.getIDs();
		            int n = arrl.length;
		            int n2 = 0;
		            while (n2 < n) {
		            	if(counter == 15)
                    		break;
		                long subId = arrl[n2];
		                User user1 = twitter3.showUser(subId);
		                if(user1.getStatusesCount() > 200 && user1.getStatusesCount() < 5000){
		                	this.ar.add(user1.getScreenName());
		                    this.arpic.add(user1.getMiniProfileImageURL());
		                    System.out.println("status : "+user1.getRateLimitStatus().getRemaining());
		                    if(user1.getRateLimitStatus().getRemaining() < 300){
		                    	counter = counter+1;
		                    	System.out.println("getDetails4 called");
		                    	System.out.println("Counter :"+counter);
		                    	getDetails4();
		                    }
		                }
		                ++n2;
		            }
		        }
		        catch (TwitterException e1) {
		            e1.printStackTrace();
		        }
		    }
			public void getDetails4() throws IOException, TwitterException {
		        String twittername = this.tname;
		        System.out.println(twittername);
		        //String consumerKey = "i98lWOVZ6DLARCIIQlx5VFOuC";
		        //String consumerSecret = "AUUpp6zwJf2DvVo0vk6w1BMrpFPGH7YY22YA4kNq5DQ4Hyrtcb";
		        //String twitterToken = "1493129694-lDWmDcfz1CGmTbs79hbGHykxTgfqOYlXBGofMfi";
		        //String twitterSecret = "NbIUCMsZ5WDEwQFHhUq6AvM10qimq2k9NEy46I35fos85";
		        TwitterFactory factory4 = new TwitterFactory();
		        Twitter twitter4 = factory4.getInstance();
		        twitter4.setOAuthConsumer(consumerKey4, consumerSecret4);
		        AccessToken accessToken4 = new AccessToken(twitterToken4, twitterSecret4);
		        twitter4.setOAuthAccessToken(accessToken4);
		        String twitterScreenName = twitter4.getScreenName();
		        
		        IDs followerIDs = twitter4.getFollowersIDs(twitterScreenName, -1);
		        long[] ids = followerIDs.getIDs();
		        String usr = twittername;
		        try {
		            long[] fofIDs;
		            User user = twitter4.showUser(usr);
		            
		            String userScreenName = user.getScreenName();
		            IDs followerIDsOfFollowers = twitter4.getFollowersIDs(user.getScreenName(), -1);
		            long[] arrl = fofIDs = followerIDsOfFollowers.getIDs();
		            int n = arrl.length;
		            int n2 = 0;
		            while (n2 < n) {
		            	if(counter == 15)
                    		break;
		                long subId = arrl[n2];
		                User user1 = twitter4.showUser(subId);
		                if(user1.getStatusesCount() > 200 && user1.getStatusesCount() < 5000){
		                	this.ar.add(user1.getScreenName());
		                    this.arpic.add(user1.getMiniProfileImageURL());
		                    System.out.println("status : "+user1.getRateLimitStatus().getRemaining());
		                    if(user1.getRateLimitStatus().getRemaining() < 300){
		                    	counter = counter+1;
		                    	System.out.println("getDetails5 called");
		                    	System.out.println("Counter :"+counter);
		                    	getDetails5();
		                    }
		                }
		                ++n2;
		            }
		        }
		        catch (TwitterException e1) {
		            e1.printStackTrace();
		        }
		    }
			public void getDetails5() throws IOException, TwitterException {
		        String twittername = this.tname;
		        System.out.println(twittername);
		        //String consumerKey = "i98lWOVZ6DLARCIIQlx5VFOuC";
		        //String consumerSecret = "AUUpp6zwJf2DvVo0vk6w1BMrpFPGH7YY22YA4kNq5DQ4Hyrtcb";
		        //String twitterToken = "1493129694-lDWmDcfz1CGmTbs79hbGHykxTgfqOYlXBGofMfi";
		        //String twitterSecret = "NbIUCMsZ5WDEwQFHhUq6AvM10qimq2k9NEy46I35fos85";
		        TwitterFactory factory5 = new TwitterFactory();
		        Twitter twitter5 = factory5.getInstance();
		        twitter5.setOAuthConsumer(consumerKey5, consumerSecret5);
		        AccessToken accessToken5 = new AccessToken(twitterToken5, twitterSecret5);
		        twitter5.setOAuthAccessToken(accessToken5);
		        String twitterScreenName = twitter5.getScreenName();
		        
		        IDs followerIDs = twitter5.getFollowersIDs(twitterScreenName, -1);
		        long[] ids = followerIDs.getIDs();
		        String usr = twittername;
		        try {
		            long[] fofIDs;
		            User user = twitter5.showUser(usr);
		            
		            String userScreenName = user.getScreenName();
		            IDs followerIDsOfFollowers = twitter5.getFollowersIDs(user.getScreenName(), -1);
		            long[] arrl = fofIDs = followerIDsOfFollowers.getIDs();
		            int n = arrl.length;
		            int n2 = 0;
		            while (n2 < n) {
		            	if(counter == 15)
                    		break;
		                long subId = arrl[n2];
		                User user1 = twitter5.showUser(subId);
		                if(user1.getStatusesCount() > 200 && user1.getStatusesCount() < 5000){
		                	this.ar.add(user1.getScreenName());
		                    this.arpic.add(user1.getMiniProfileImageURL());
		                    System.out.println("status : "+user1.getRateLimitStatus().getRemaining());
		                    if(user1.getRateLimitStatus().getRemaining() < 300){
		                    	counter = counter+1;
		                    	System.out.println("getDetails6 called");
		                    	System.out.println("Counter :"+counter);
		                    	getDetails6();
		                    }
		                }
		                ++n2;
		            }
		        }
		        catch (TwitterException e1) {
		            e1.printStackTrace();
		        }
		    }
			public void getDetails6() throws IOException, TwitterException {
		        String twittername = this.tname;
		        System.out.println(twittername);
		        //String consumerKey = "i98lWOVZ6DLARCIIQlx5VFOuC";
		        //String consumerSecret = "AUUpp6zwJf2DvVo0vk6w1BMrpFPGH7YY22YA4kNq5DQ4Hyrtcb";
		        //String twitterToken = "1493129694-lDWmDcfz1CGmTbs79hbGHykxTgfqOYlXBGofMfi";
		        //String twitterSecret = "NbIUCMsZ5WDEwQFHhUq6AvM10qimq2k9NEy46I35fos85";
		        TwitterFactory factory6 = new TwitterFactory();
		        Twitter twitter6 = factory6.getInstance();
		        twitter6.setOAuthConsumer(consumerKey6, consumerSecret6);
		        AccessToken accessToken6 = new AccessToken(twitterToken6, twitterSecret6);
		        twitter6.setOAuthAccessToken(accessToken6);
		        String twitterScreenName = twitter6.getScreenName();
		        
		        IDs followerIDs = twitter6.getFollowersIDs(twitterScreenName, -1);
		        long[] ids = followerIDs.getIDs();
		        String usr = twittername;
		        try {
		            long[] fofIDs;
		            User user = twitter6.showUser(usr);
		            
		            String userScreenName = user.getScreenName();
		            IDs followerIDsOfFollowers = twitter6.getFollowersIDs(user.getScreenName(), -1);
		            long[] arrl = fofIDs = followerIDsOfFollowers.getIDs();
		            int n = arrl.length;
		            int n2 = 0;
		            while (n2 < n) {
		            	if(counter == 15)
                    		break;
		                long subId = arrl[n2];
		                User user1 = twitter6.showUser(subId);
		                if(user1.getStatusesCount() > 200 && user1.getStatusesCount() < 5000){
		                	this.ar.add(user1.getScreenName());
		                    this.arpic.add(user1.getMiniProfileImageURL());
		                    System.out.println("status : "+user1.getRateLimitStatus().getRemaining());
		                    if(user1.getRateLimitStatus().getRemaining() < 300){
		                    	counter = counter+1;
		                    	System.out.println("getDetails7 called");
		                    	System.out.println("Counter :"+counter);
		                    	getDetails7();
		                    }
		                }
		                ++n2;
		            }
		        }
		        catch (TwitterException e1) {
		            e1.printStackTrace();
		        }
		    }
			public void getDetails7() throws IOException, TwitterException {
		        String twittername = this.tname;
		        System.out.println(twittername);
		        //String consumerKey = "i98lWOVZ6DLARCIIQlx5VFOuC";
		        //String consumerSecret = "AUUpp6zwJf2DvVo0vk6w1BMrpFPGH7YY22YA4kNq5DQ4Hyrtcb";
		        //String twitterToken = "1493129694-lDWmDcfz1CGmTbs79hbGHykxTgfqOYlXBGofMfi";
		        //String twitterSecret = "NbIUCMsZ5WDEwQFHhUq6AvM10qimq2k9NEy46I35fos85";
		        TwitterFactory factory7 = new TwitterFactory();
		        Twitter twitter7 = factory7.getInstance();
		        twitter7.setOAuthConsumer(consumerKey7, consumerSecret7);
		        AccessToken accessToken7 = new AccessToken(twitterToken7, twitterSecret7);
		        twitter7.setOAuthAccessToken(accessToken7);
		        String twitterScreenName = twitter7.getScreenName();
		        
		        IDs followerIDs = twitter7.getFollowersIDs(twitterScreenName, -1);
		        long[] ids = followerIDs.getIDs();
		        String usr = twittername;
		        try {
		            long[] fofIDs;
		            User user = twitter7.showUser(usr);
		            
		            String userScreenName = user.getScreenName();
		            IDs followerIDsOfFollowers = twitter7.getFollowersIDs(user.getScreenName(), -1);
		            long[] arrl = fofIDs = followerIDsOfFollowers.getIDs();
		            int n = arrl.length;
		            int n2 = 0;
		            while (n2 < n) {
		            	if(counter == 15)
                    		break;
		                long subId = arrl[n2];
		                User user1 = twitter7.showUser(subId);
		                if(user1.getStatusesCount() > 200 && user1.getStatusesCount() < 5000){
		                	this.ar.add(user1.getScreenName());
		                    this.arpic.add(user1.getMiniProfileImageURL());
		                    System.out.println("status : "+user1.getRateLimitStatus().getRemaining());
		                    if(user1.getRateLimitStatus().getRemaining() < 300){
		                    	counter = counter+1;
		                    	System.out.println("getDetails8 called");
		                    	System.out.println("Counter :"+counter);
		                    	getDetails8();
		                    }
		                }
		                ++n2;
		            }
		        }
		        catch (TwitterException e1) {
		            e1.printStackTrace();
		        }
		    }
			public void getDetails8() throws IOException, TwitterException {
		        String twittername = this.tname;
		        System.out.println(twittername);
		        //String consumerKey = "i98lWOVZ6DLARCIIQlx5VFOuC";
		        //String consumerSecret = "AUUpp6zwJf2DvVo0vk6w1BMrpFPGH7YY22YA4kNq5DQ4Hyrtcb";
		        //String twitterToken = "1493129694-lDWmDcfz1CGmTbs79hbGHykxTgfqOYlXBGofMfi";
		        //String twitterSecret = "NbIUCMsZ5WDEwQFHhUq6AvM10qimq2k9NEy46I35fos85";
		        TwitterFactory factory8 = new TwitterFactory();
		        Twitter twitter8 = factory8.getInstance();
		        twitter8.setOAuthConsumer(consumerKey8, consumerSecret8);
		        AccessToken accessToken8 = new AccessToken(twitterToken8, twitterSecret8);
		        twitter8.setOAuthAccessToken(accessToken8);
		        String twitterScreenName = twitter8.getScreenName();
		        
		        IDs followerIDs = twitter8.getFollowersIDs(twitterScreenName, -1);
		        long[] ids = followerIDs.getIDs();
		        String usr = twittername;
		        try {
		            long[] fofIDs;
		            User user = twitter8.showUser(usr);
		            
		            String userScreenName = user.getScreenName();
		            IDs followerIDsOfFollowers = twitter8.getFollowersIDs(user.getScreenName(), -1);
		            long[] arrl = fofIDs = followerIDsOfFollowers.getIDs();
		            int n = arrl.length;
		            int n2 = 0;
		            while (n2 < n) {
		            	if(counter == 15)
                    		break;
		                long subId = arrl[n2];
		                User user1 = twitter8.showUser(subId);
		                if(user1.getStatusesCount() > 200 && user1.getStatusesCount() < 5000){
		                	this.ar.add(user1.getScreenName());
		                    this.arpic.add(user1.getMiniProfileImageURL());
		                    System.out.println("status : "+user1.getRateLimitStatus().getRemaining());
		                    if(user1.getRateLimitStatus().getRemaining() < 300){
		                    	counter = counter+1;
		                    	System.out.println("getDetails1 called");
		                    	System.out.println("Counter :"+counter);
		                    	getDetails1();
		                    }
		                }
		                ++n2;
		            }
		        }
		        catch (TwitterException e1) {
		            e1.printStackTrace();
		        }
		    }
		}