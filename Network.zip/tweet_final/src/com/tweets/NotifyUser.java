package com.tweets;

import java.io.*;
import java.util.ArrayList;

import com.sun.org.apache.xerces.internal.util.SynchronizedSymbolTable;

import twitter4j.DirectMessage;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.auth.AccessToken;

public class NotifyUser {
	
    String friends;
    String relatives;
    String colleagues;
	
    public ArrayList<String> notifyUserFollower = new ArrayList();
    public ArrayList<String> notifyUserFollowing = new ArrayList();
	
    String fileName1 = "Followers.csv";
    String fileName2 = "Followings.csv";
    
    String home = System.getProperty("user.home");
	File file1 = new File(home+"/Downloads/" + fileName1); 
	File file2 = new File(home+"/Downloads/" + fileName2); 
    
    public ArrayList getFollowers() throws Exception {
        this.file_read(file1);
        return this.notifyUserFollower;
    }
    
    public ArrayList getFollowings() throws Exception {
        this.file_read(file2);
        return this.notifyUserFollowing;
    }
    
	public void file_read(File file12) 
    {
     friends = "";
     relatives = "";
     colleagues = "";
        try
        {
            FileInputStream fis = new FileInputStream(file12);
            BufferedReader br = new BufferedReader(new InputStreamReader(fis,"UTF-8"));
            String line;
            br.readLine();
            while((line = br.readLine())!=null)
            {
                friends+=line+"\n";
                if(line.equals("")){
                	while((line = br.readLine())!=null)
                    {
                        relatives+=line+"\n";
                        if(line.equals("")){
                        	while((line = br.readLine())!=null)
                            {
                                colleagues+=line+"\n";
                                if(line.equals(""))
                                	break;
                            }
                        }
                        	
                    }
                	
                }
                
            }
            System.out.println("Friends:\n"+friends);
            System.out.println("Relatives:\n"+relatives);
            System.out.println("Colleagues:\n"+colleagues);
            this.notify_user();
            fis.close();
        }catch(IOException f){}
    }
	
	
	public void notify_user() {
		
		System.out.println("Inside notify_user method");
		 System.out.println("Friends in notify method:\n"+friends);
         System.out.println("Relatives in notify method:\n"+relatives);
         System.out.println("Colleagues in notify method:\n"+colleagues);
	/*	DirectMessage directMessage = null;
		String friendStatus = "";
		String relativeStatus = "";
		String colleagueStatus = "";
		
		try {
			
			String consumerKey = "WFCzqcxfKjgufWAlsRo8cQkv3";
	        String consumerSecret = "HRxLaG0G5rjQ8Li6mGiJMonrv1gtS0AXzGnYgtmKa7ykTyHSkh";
	        String twitterToken = "774714199721123840-uPZakNuIv9GyNBpJnvK6IAb5mrNA4Xu";
	        String twitterSecret = "ksJRzHop2Bk0ZxOSQxIr4wr2iMzWmrjjX1R3u5vFd57nA";
	        TwitterFactory factory = new TwitterFactory();
	        Twitter twitter = factory.getInstance();
	        twitter.setOAuthConsumer(consumerKey, consumerSecret);
	        AccessToken accessToken = new AccessToken(twitterToken, twitterSecret);
	        twitter.setOAuthAccessToken(accessToken);
		
            String friendList[] = friends.split("\n");
            for(int i =0;i<friendList.length;i++){
            	System.out.println("Friends are:"+friendList[i]);
            }
            
            String relativeList[] = relatives.split("\n");
            for(int i =0;i<relativeList.length;i++){
            	System.out.println("Relatives are:"+relativeList[i]);
            }
            
            String colleagueList[] = colleagues.split("\n");
            for(int i =0;i<colleagueList.length;i++){
            	System.out.println("colleagues are:"+colleagueList[i]);
            }
	        
	        
	    for(int i =0;i<friendList.length;i++){    
	    	friendStatus = "Dear @"+friendList[i]+"You have been selected by your friend @SudheshSolomon";
	    }
	    
	    for(int i =0;i<relativeList.length;i++){    
			relativeStatus = "Dear @"+relativeList[i]+"You have been selected by your relative @SudheshSolomon";
		    }
	    
	    for(int i =0;i<colleagueList.length;i++){    
			colleagueStatus = "Dear @"+colleagueList[i]+"You have been selected by your colleague @SudheshSolomon";
		    }

		//Twitter twitter = getTwitter();
		//AccessToken accessToken = new AccessToken(accessTkn, accessTokenSecret);
		twitter.setOAuthAccessToken(accessToken);
		//directMessage = twitter.sendDirectMessage(senderScreenName, message);
		Status friendstatus = twitter.updateStatus(friendStatus);
		Status relativestatus = twitter.updateStatus(relativeStatus);
		Status colleaguestatus = twitter.updateStatus(colleagueStatus);
		System.out.println("notified friends");
		System.out.println("notified relatives");
		System.out.println("notified colleagues");
		} catch (TwitterException ex) {
		//Logger.getLogger(TwitterConnector.class.getName()).log(Level.SEVERE, null, ex);
		}
		}
*/
	
	//public static void main(String args[]) throws TwitterException{
		//String path1 = "F:\\Followings.csv";
		//String path2 = "F:\\Followers.csv";
		//NotifyUser nu = new NotifyUser();
		//nu.file_read(path1);
		//nu.file_read(path2);
	//}
	}
}
